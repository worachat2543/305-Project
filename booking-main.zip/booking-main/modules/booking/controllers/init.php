<?php
/**
 * @filesource modules/booking/controllers/init.php
 *
 * @copyright 2016 Goragod.com
 * @license http://www.kotchasan.com/license/
 *
 * @see http://www.kotchasan.com/
 */

namespace Booking\Init;

/**
 * Init Module
 *
 * @author Goragod Wiriya <admin@goragod.com>
 *
 * @since 1.0
 */
class Controller
{
    /**
     * รายการ permission ของโมดูล
     *
     * @param array $permissions
     *
     * @return array
     */
    public static function updatePermissions($permissions)
    {
        $permissions['can_manage_room'] = '{LNG_Can manage the} {LNG_Room}';
        $permissions['can_approve_room'] = '{LNG_Can be approve} ({LNG_Room})';
        return $permissions;
    }
}
